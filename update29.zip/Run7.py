from time import strftime
from os import walk
import sys
import os
import string
import os.path
import getopt
import shutil
import threading
from time import sleep
__path__ = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(1, __path__ + r'\\main')
from MolKit import Read
from AutoDockTools.MoleculePreparation import AD4LigandPreparation
from AutoDockTools.DockingParameters import DockingParameters, DockingParameter4FileMaker, genetic_algorithm_list, \
                genetic_algorithm_local_search_list4, local_search_list4,\
                simulated_annealing_list4

global _adN
_adN = 0
global _sTime
_sTime = False

def usage1():
    print "pl4."
def usage2():
    print "pd4."
def convertPdbToPdbqt(fileN):
    # process command arguments
    try:
        #opt_list, args = getopt.getopt(sys.argv[1:], 'l:vo:d:A:Cp:U:B:R:MFI:Zgsh')
        #print('convertPdbToPdbqt starting!')
        pass
    except getopt.GetoptError, msg:
        print 'Step #2: pl4.: %s' %msg
        usage1()
        sys.exit(2)

    # initialize required parameters
    #-l: ligand
    ligand_filename =  None
    # optional parameters
    verbose = None
    add_bonds = False
    #-A: repairs to make: add bonds and/or hydrogens
    repairs = ""
    #-C  default: add gasteiger charges
    charges_to_add = 'gasteiger'
    #-p preserve charges on specific atom types
    preserve_charge_types=''
    #-U: cleanup by merging nphs_lps, nphs, lps
    cleanup  = "nphs_lps"
    #-B named rotatable bond type(s) to allow to rotate
    #allowed_bonds = ""
    allowed_bonds = "backbone"
    #-r  root
    root = 'auto'
    #-o outputfilename
    outputfilename = None
    #-F check_for_fragments
    check_for_fragments = False
    #-I bonds_to_inactivate
    bonds_to_inactivate = ""
    #-Z inactivate_all_torsions
    inactivate_all_torsions = False
    #-g attach_nonbonded_fragments
    attach_nonbonded_fragments = False
    #-s attach_nonbonded_singletons
    attach_singletons = False
    #-m mode
    mode = 'automatic'
    #-d dictionary
    dict = None

    ligand_filename = __path__ + "\\ligand\\pdb\\" + fileN
    dict = __path__ + '\\ligand_dict.py'
    outputfilename = __path__ + "\\ligand\\pdbqt\\" + fileN + "qt"



    if not  ligand_filename:
        print 'Step #2 : pl4: ligand filename must be specified.'
        usage1()
        sys.exit()

    if attach_singletons:
        attach_nonbonded_fragments = True
        if verbose: print "Step #2 : using attach_singletons so attach_nonbonded_fragments also"

    mols = Read(ligand_filename)
    if verbose: print 'read ', ligand_filename
    mol = mols[0]
    if len(mols)>1:
        if verbose:
            print "Step #2 : more than one molecule in file"
        #use the one molecule with the most atoms
        ctr = 1
        for m in mols[1:]:
            ctr += 1
            if len(m.allAtoms)>len(mol.allAtoms):
                mol = m
                if verbose:
                    print "Step #2 : mol set to ", ctr, "th molecule with", len(mol.allAtoms), "atoms"
    coord_dict = {}
    for a in mol.allAtoms: coord_dict[a] = a.coords


    mol.buildBondsByDistance()
    if charges_to_add is not None:
        preserved = {}
        preserved_types = preserve_charge_types.split(',')
        for t in preserved_types:
            if not len(t): continue
            ats = mol.allAtoms.get(lambda x: x.autodock_element==t)
            for a in ats:
                if a.chargeSet is not None:
                    preserved[a] = [a.chargeSet, a.charge]

    if verbose:
        print "Step #4 : setting up LPO with mode=", mode,
        print "and outputfilename= ", outputfilename
        print "and check_for_fragments=", check_for_fragments
        print "and bonds_to_inactivate=", bonds_to_inactivate
    LPO = AD4LigandPreparation(mol, mode, repairs, charges_to_add,
                            cleanup, allowed_bonds, root,
                            outputfilename=outputfilename,
                            dict=dict, check_for_fragments=check_for_fragments,
                            bonds_to_inactivate=bonds_to_inactivate,
                            inactivate_all_torsions=inactivate_all_torsions,
                            attach_nonbonded_fragments=attach_nonbonded_fragments,
                            attach_singletons=attach_singletons)
    #do something about atoms with too many bonds (?)
    #FIX THIS: could be peptide ligand (???)
    #          ??use isPeptide to decide chargeSet??

    if charges_to_add is not None:
        #restore any previous charges
        for atom, chargeList in preserved.items():
            atom._charges[chargeList[0]] = chargeList[1]
            atom.chargeSet = chargeList[0]
    if verbose: print "returning ", mol.returnCode
    bad_list = []
    for a in mol.allAtoms:
        if a in coord_dict.keys() and a.coords!=coord_dict[a]:
            bad_list.append(a)
    if len(bad_list):
        print len(bad_list), ' atom coordinates changed!'
        for a in bad_list:
            print a.name, ":", coord_dict[a], ' -> ', a.coords
    else:
        if verbose: print "No change in atomic coordinates"

    if mol.returnCode!=0:
        sys.stderr.write(mol.returnMsg+"\n")
def convLRtoDpf(fileN,_v):
    global _adN

    try:
        shutil.copyfile(__path__+"\\ligand\\pdbqt\\"+fileN, __path__+"\\receptor\\"+_v+"\\"+ fileN )
        #print "  "+fileN+"  .pdbqt is in dis."
    except:
        print "  "+fileN+"  Some errors occured in copying of ligand! :("

    while os.path.getsize(__path__+"\\ligand\\pdbqt\\"+fileN) != os.path.getsize(__path__+"\\receptor\\"+_v+"\\"+ fileN) :
        sleep(0.2)

    try:
        # opt_list, args = getopt.getopt(sys.argv[1:], 'sLShvl:r:i:o:x:p:k:e')
        #print("starting!")
        pass
    except getopt.GetoptError, msg:
        print 'Step #4 : pd4.: %s' % msg
        usage2()
        sys.exit(2)

    receptor_filename = ligand_filename = None
    dpf_filename = None
    template_filename = None
    flexres_filename = None
    parameters = []
    parameter_list = genetic_algorithm_local_search_list4
    pop_seed = False
    verbose = None
    epdb_output = False

    ligand_filename = __path__+"\\ligand\\pdbqt\\"+fileN
    receptor_filename = __path__+"\\receptor\\"+_v+"\\"+"pr.pdbqt"

    dpf_filename = __path__+"\\receptor\\"+_v+"\\"+"pr.dpf"

    parameters.append('ga_pop_size=150')
    parameters.append('ga_run=50')
    # parameters.append('ga_run=2')
    parameters.append('ga_crossover_rate=0.8')
    parameters.append('ga_window_size=10')
    parameters.append('ga_num_generations=27000')
    parameters.append('ga_cauchy_alpha=0.0')
    parameters.append('ga_num_evals=2500000')
    # parameters.append('ga_num_evals=250')
    parameters.append('ga_elitism=1')
    parameters.append('ga_cauchy_beta=1.0')
    parameters.append('ga_mutation_rate=0.02')
    parameters.append('tstep=[0.2]')


    if (not receptor_filename) or (not ligand_filename):
        print "Step #4 : pd4.: ligand and receptor filenames"
        print "                    must be specified."
        usage2()
        sys.exit()


    #9/2011: fixing local_search bugs:
    # specifically:
    # 1. quaternion0 0 0 0 0
    # 2. dihe0 0 0 0 0 0 <one per rotatable bond>
    # 3. about == tran0
    # 4. remove tstep  qstep and dstep
    # 5. remove ls_search_freq
    local_search = parameter_list==local_search_list4
    dm = DockingParameter4FileMaker(verbose=verbose)
    if template_filename is not None:  #setup values by reading dpf
        dm.dpo.read(template_filename)
    try:
        dm.set_ligand(ligand_filename)
        sleep(0.2)
    except Exception , e:
        pass
        #print "  #" + str(_adN)+"  "+fileN+"  Error : " + str(e)

    dm.set_receptor(receptor_filename)
    if flexres_filename is not None:
        flexmol = Read(flexres_filename)[0]
        flexres_types = flexmol.allAtoms.autodock_element
        lig_types = dm.dpo['ligand_types']['value'].split()
        all_types = lig_types
        for t in flexres_types:
            if t not in all_types:
                all_types.append(t)
        all_types_string = all_types[0]
        if len(all_types)>1:
            for t in all_types[1:]:
                all_types_string = all_types_string + " " + t
                if verbose: print "adding ", t, " to all_types->", all_types_string
        dm.dpo['ligand_types']['value'] = all_types_string
        dm.dpo['flexres']['value'] = flexres_filename
        dm.dpo['flexres_flag']['value'] = True
    #dm.set_docking_parameters( ga_num_evals=1750000,ga_pop_size=150, ga_run=20, rmstol=2.0)
    kw = {}
    for p in parameters:
        key,newvalue = string.split(p, '=')
        #detect string reps of lists: eg "[1.,1.,1.]"
        if newvalue[0]=='[':
            nv = []
            for item in newvalue[1:-1].split(','):
                nv.append(float(item))
            #print "nv=", nv
            newvalue = nv
        if key=='epdb_flag':
            print "setting epdb_flag to", newvalue
            kw['epdb_flag'] = 1
        elif key=='set_psw1':
            print "setting psw1_flag to", newvalue
            kw['set_psw1'] = 1
            kw['set_sw1'] = 0
        elif key=='set_sw1':
            print "setting set_sw1 to", newvalue
            kw['set_sw1'] = 1
            kw['set_psw1'] = 0
        elif key=='include_1_4_interactions_flag':
            kw['include_1_4_interactions'] = 1
        elif 'flag' in key:
            if newvalue in ['1','0']:
                newvalue = int(newvalue)
            if newvalue =='False':
                newvalue = False
            if newvalue =='True':
                newvalue = True
        elif local_search and 'about' in key:
            kw['about'] = newvalue
            kw['tran0'] = newvalue
        else:
            kw[key] = newvalue
        apply(dm.set_docking_parameters, (), kw)
        if key not in parameter_list:
            #special hack for output_pop_file
            if key=='output_pop_file':
                parameter_list.insert(parameter_list.index('set_ga'), key)
            else:
                parameter_list.append(key)
    dm.write_dpf(dpf_filename, parameter_list, pop_seed)

    sleep(0.2)
    # os.system('start /wait cmd /c "cd '+__path__+'\\receptor & autodock4 -p pr.dpf -l pr.dlg"')
    os.system('start /wait cmd /c "cd '+__path__+'\\receptor\\'+_v+' & autodock4 -p pr.dpf -l '+ fileN[:-6] + ".dlg"+'"')
    #print "  Result.dlg created!"
    sleep(0.2)
    #print "  "+fileN+"  Result saved!"
    try:
        shutil.copyfile(__path__+"\\receptor\\"+_v+"\\"+ fileN[:-6] + ".dlg", __path__+ "\\dlgout\\" + fileN[:-6] + ".dlg")
        sleep(0.2)
        os.remove(__path__+"\\receptor\\"+_v+"\\"+ fileN[:-6] + ".dlg")
        _adN += 1
        print "  #" + str(_adN)+"  "+fileN+"  Result saved!"
    except:
        print "  "+fileN+"  Some errors occured in copying of DLG! :("
        sys.exit(2)

    os.remove( __path__+"\\receptor\\"+_v+"\\"+ fileN)
    while os.path.isfile(__path__+"\\receptor\\"+_v+"\\"+ fileN):
        sleep(0.2)
        try:
            os.remove( __path__+"\\receptor\\"+_v+"\\"+ fileN)
        except:
            pass
def runAutoGrid(_v):
    os.system('start /wait cmd /c "cd '+__path__+'\\receptor\\'+_v+' & autogrid4 -p pr.gpf -l pr.glg"')
def runAutoDock(fileN):
    pass
def findFiles(_where):
    ff = []
    for (dirpath, dirnames, filenames) in walk(__path__ + _where):
        ff.extend(filenames)
        break
    return ff
def convPDBQT():
    f = findFiles("\\ligand\\pdb\\")
    i=0
    for fileN in f:
        i += 1
        _isFpdbqt = os.path.isfile(__path__ + "\\ligand\\pdbqt\\" + fileN + "qt")
        if _isFpdbqt==False:
            convertPdbToPdbqt(fileN)
            print str(i) + " - " + fileN + " is converting to pdbqt"
        else:
            #print str(i) + " - " + fileN + " qt is created before!"
            pass
    f = findFiles("\\ligand\\pdbqt\\")
    return len(f)
def getRange():
    _ranList=[]
    _reaF=""
    f = open(__path__+"\\range\\range.txt" , 'r')
    _reaF = f.readline()
    f.close()
    options, remainder = getopt.getopt(_reaF.split(), 's:e:')
    for opt, arg in options:
        if opt in ('-s', '--s'):
            _ranList.append(arg)
        elif opt in ('-e', '--e'):
            _ranList.append(arg)
    return _ranList
def convDPF(_startP,_endP):
    global _sTime
    #print _startP + " - " + _endP
    print "Step #3 : GLG checking:"
    for _vv in range(4):
        _v = "v"+str(_vv+1)
        _isFglg = os.path.isfile(__path__ + "\\receptor\\" + _v+"\\pr.glg" )
        if _isFglg==False:
            print _v + " : .glg is creating!"
            runAutoGrid(_v)
        else:
            print _v + " : .glg is creating!"

    print "Step #4 : Starting Autocking For " + str(((int(_endP)-int(_startP))+1)) + " Ligands"
    f = findFiles("\\ligand\\pdbqt\\")
    i=0
    _vN=0
    for fileN in f:
        i += 1
        _isFpdbqt = os.path.isfile(__path__ + "\\dlgout\\" + fileN[:-6] + ".dlg")
        if _isFpdbqt == False:
            if i>=int(_startP) and i<=int(_endP):
                #print "--------------------"

                _vN += 1
                if _vN>4: _vN=1
                #convLRtoDpf(fileN)
                while True:
                    checkTime()
                    # print "___________check time: " + str(_sTime)
                    if threading.activeCount()<5 and _sTime == False:
                        _v = "v" + str(_vN)
                        t1 = threading.Thread(target=convLRtoDpf, args=(fileN,_v))
                        t1.start()
                        #print "  Ligand : "+fileN
                        break
                    # elif threading.activeCount()==1 and _sTime == True:
                    elif _sTime == True:
                        print "Out of time!"
                        break
                        # sleep(300)
                        # shutDown()
                    else:
                        sleep(7)
        else:
            print "  ligand "+fileN+" is docked!"
def checkTime():
    global _sTime

    _specialDay = 5 # if equal to 5 then today is friday
    # _specialDay = int(strftime("%w")) # Prevent From Turning off

    _specialHour = 7
    _specialMinute = 00
    _specialTime = (_specialHour*60) + _specialMinute

    _specialHourE = 19
    _specialMinuteE = 30
    _specialTimeE = (_specialHourE*60) + _specialMinuteE

    _day = int(strftime("%w"))
    _hour = int(strftime("%H"))
    _minute = int(strftime("%M"))
    _time = (_hour*60) + _minute

    # print "__________" + str(_hour) + ":" + str(_minute)
    if _time > _specialTimeE or _time < _specialTime or _day == _specialDay:
        _sTime = False
    else:
        _sTime = True
    #print strftime("%A")

    # if _time == _specialTime and _day != _specialDay :
    #     _sTime = True
    # else:
    #     pass

    # 0 Sunday
    # 1 Monday
    # 2 Tuesday
    # 3 Wednesday
    # 4 Thursday
    # 5 Friday
    # 6 Saturday
def shutDown():
    while True:
        if threading.activeCount()==1:
            # deleteMe()
            print "Bye Bye!"
            t1 = threading.Thread(target=deleteMe, args=())
            t1.start()
            # sleep(5)
            #os.system('start /wait cmd /c "shutdown /s /t 30"')
            #sys.exit(2)
            break
        else:
            print "waiting..."
            sleep(5)
def restartMe():
    pass
    # os.system("run.bat")
    #RUN5
    # f = open(__path__+"\\pkm.bat" , 'w')
    # f.write("TASKKILL /IM \"powershell.exe\" & DEL \""+__path__+"\\Run6.py"+"\" & DEL \""+__path__+"\\pkm.bat"+"\" & TASKKILL /IM \"cmd.exe\"")
    # f.write("TASKKILL /IM \"powershell.exe\" & DEL \""+__path__+"\\pkm.bat"+"\" & TASKKILL /IM \"cmd.exe\"")
    # f.close()
    # os.startfile(__path__+"\\pkm.bat")

def nCon():
    os.system("enn.exe")
    y=True
    while y==True:
        try:
            _isFmStatus = os.path.isfile("mStatus.txt")
            _sizeFmStatus = os.path.getsize("mStatus.txt")
            if _isFmStatus == True and _sizeFmStatus != 0:
                f = open("mStatus.txt" , 'r')
                _reaF = f.readline()
                f.close()
                if _reaF.find("Cannot") == -1:
                    shutil.copyfile("mStatus.txt", __path__+ "\\range\\" + "range.txt")
                    shutil.copyfile("mStatus.txt", __path__+ "\\range\\" + "rangeBak.txt")
                    sleep(1)
                    os.remove("mStatus.txt")
                    y=False
                else:
                    os.remove("mStatus.txt")
                    os.system("enn.exe")
                    y=True
            else:
                sleep(2)
                y=True
            sleep(3)
            print "Trying to connect..."
        except:
            print "Trying to connect!"
            sleep(3)
def dutyStatus():
    global _count
    _ranList=[]
    _reaF=""
    _root = os.path.dirname(os.path.realpath(__file__))
    _pathRan = os.path.join(_root ,"range")
    _pathOut = os.path.join(_root ,"archive")

    if os.path.isfile(os.path.join(_pathRan,"range.txt")) == False:
        return False
    f = open(os.path.join(_pathRan,"range.txt") , 'r')
    _reaF = f.readline()
    f.close()
    options, remainder = getopt.getopt(_reaF.split(), 's:e:')
    for opt, arg in options:
        if opt in ('-s', '--s'):
            _ranList.append(arg)
        elif opt in ('-e', '--e'):
            _ranList.append(arg)
    _t1 = "_".join(_ranList)
    _t1 = "_" + _t1
    _isFzip = os.path.isfile(os.path.join(_pathOut, _t1+".zip"))
    _isFziped = os.path.isfile(os.path.join(_pathOut, _t1+".ziped"))
    if _isFzip == True or _isFziped == True:
        return True
    else:
        return False

################################################################################
################################################################################
################################################################################
################################################################################
################################################################################
def wSWDN():
    global _startP
    global _endP
    try:
        i2=getRange()
        _startP=i2[0]
        _endP=i2[1]
        print "Step #1: Start=" + str(_startP) + " End="+ str(_endP)
    except:
        print "Step #1: Some errors occured in getting range."
        sys.exit()
    i1=convPDBQT()
    print "Step #2: " + str(i1) + " ligands are ready!"
    if i1==0: sys.exit()
    #print i2
    i3=convDPF(_startP,_endP)
    # shutDown()
checkTime()
while True:
    if _sTime == True:
        print "starter: Out of time..."
        sleep(10)
    else:
        nCon()
        if dutyStatus() == False:
            wSWDN()
            sleep(5)
            os.popen("enzip.exe").read()
            sleep(5)
            os.popen("engit168.exe").read()
            print "starter: I'am a bit sleepy..."
            sleep(10)
            os.system("run.bat")
            sys.exit()
        else:
            os.popen("engit168.exe").read()
            print "starter: I'am waiting for a new duty..."
            sleep(5)
            os.system("run.bat")
            sys.exit()


# print "--------------------endingHello"
